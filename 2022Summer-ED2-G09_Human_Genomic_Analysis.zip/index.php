<!DOCTYPE html>
<?php
   if(isset($_FILES['anomalyFile'])){
      $errors= array();
      $file_name = $_FILES['anomalyFile']['name'];
      $file_size = $_FILES['anomalyFile']['size'];
      $file_tmp = $_FILES['anomalyFile']['tmp_name'];
      $file_type = $_FILES['anomalyFile']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['anomalyFile']['name'])));
      $extensions= array("gz");
     
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a vcf.gz file.";
      }
    
       $new_file = "anomaly.vcf.gz";

      if(empty($errors)==true) {
        move_uploaded_file($file_tmp,"writable/".$new_file);
        // Calling python script
        //$command = 'nohup ipython3 3rd_file_final_show.py > writable/output_file.txt 2> error.err < /dev/null &';
        $command = 'ipython3 3rd_file_final.py';
        $output = shell_exec($command);
   
        $file = fopen("./writable/output_file.txt", "w");
        fwrite($file, $output, PHP_EOL);
        fclose($file);
      }
   }
?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Anomaly.com</title>
        <!-- Favicon-->
        <link rel="icon" type="anomalyFile/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">Anomaly</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link" href="#output">Output</a></li>
                        <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="#portfolio">Portfolio</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 h-100">
                <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-8 align-self-end">
                    <?php if (isset($_FILES['anomalyFile']) && empty($errors)) { ?>
                       <h1 class="text-white font-weight-bold">Success</h1>
                    <?php } else { ?>
                        <h1 class="text-white font-weight-bold">Submit your file for anomaly detection!</h1>
                    <?php } ?>  
                    
                        <hr class="divider" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                  
                        <p class="text-white-75 mb-5">This is a web application that detects anomalous regions automatically with visualization efficiently and accurately </p>
                        <form action = "" method = "POST" enctype = "multipart/form-data">
                            <input class="form-control form-control-lg" id="formFileLg" name="anomalyFile" type="file">
                            <button type="submit" class="btn btn-primary btn-xl my-4">Upload File</button>
                        </form>    

                        <div class='container'>
                            <h2 class="text-white font-weight-bold">Download Output Below</h2>                            
                            <a href="output.zip">
                                <download="output.zip" class="btn btn-primary btn-xl my-4" alt="zipFile">Download Output
                            </a>
                    </div>

                        <?php if (isset($_FILES['anomalyFile']) && empty($errors)) { ?>
                            <div class="alert alert-success px-3" style="text-align: left" role="alert">
                                <h3>Success!!!</h3>
                                <div>Sent file: <?php echo $_FILES['anomalyFile']['name']; ?></div>
                                <div>File size: <?php echo $_FILES['anomalyFile']['size']; ?></div>
                                <div>File type: <?php echo $_FILES['anomalyFile']['type']; ?></div>
                            </div>
                        <?php } elseif(!empty($errors)) { ?>
                            <div class="alert alert-danger px-3" style="text-align: left" role="alert">
                                <h3>Error!!!</h3>
                                <div>Sent file: <?php echo $_FILES['anomalyFile']['name']; ?></div>
                                <div>File size: <?php echo $_FILES['anomalyFile']['size']; ?></div>
                                <div>File type: <?php echo $_FILES['anomalyFile']['type']; ?></div>
                                <?php foreach($errors as $error) { 
                                    echo $error;
                                }
                                ?>
                            </div>
                        <?php } ?>

                        
                        <?php
                            //if(isset($_FILES['zipFile']) && empty(errors)){
                                // This is a work in progress hehe
                                // Get real path for our folder
                                $rootPath = realpath('/home/Aviweb/anomaly.com/figures');

                                // Initialize archive object
                                $zip = new ZipArchive();
                                $zip->open('output.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE);

                                // Create recursive directory iterator
                                /** @var SplFileInfo[] $files */
                                $files = new RecursiveIteratorIterator(
                                    new RecursiveDirectoryIterator($rootPath),
                                    RecursiveIteratorIterator::LEAVES_ONLY
                                );

                                foreach ($files as $name => $file)
                                {
                                    // Skip directories (they would be added automatically)
                                    if (!$file->isDir())
                                    {
                                        // Get real and relative path for current file
                                        $filePath = $file->getRealPath();
                                        $relativePath = substr($filePath, strlen($rootPath) + 1);

                                        $zip->addFile($filePath, $relativePath);
                                    }
                                }

                                $zip->close();  
                            //}
                        ?>

                    </div>
                </div>
            </div>
        </header>
        <!-- Output-->
        <section class="page-section bg-primary" id="output">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-8 text-center">
                        <h2 class="text-white mt-0">Here is your output!</h2>
                        <hr class="divider divider-light" />
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="10"><?php echo $output?></textarea>
                    </div>
                </div>
            </div>
        </section>

        <!-- About-->
        <section class="page-section" id="about">
            <div class="container px-4 px-lg-5">
                <h2 class="text-center mt-0">About Us</h2>
                <hr class="divider" />
                <div class="row gx-4 gx-lg-5">
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <div class="mb-2"><i class="bi-laptop fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">Avigail Martinez (Full Stack/Web Developer)</h3>
                            <p class="text-muted mb-0">Hello! I am a senior at Florida Atlantic University graduating with a Computer Science major in summer of 2022. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <div class="mb-2"><i class="bi-gem fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">John Callaghan (Team Lead/Developer)</h3>
                            <p class="text-muted mb-0">Hi! I'm John Callaghan and I'm currently studying Computer Science and Data Science at Florida Atlantic University 
                                with an expected graduation date of 2022.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <div class="mb-2"><i class="bi-laptop fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">Oasis Husband (Back-end/Developer)</h3>
                            <p class="text-muted mb-0">Hello! I am currently a senior at Florida Atlantic University and will graduate with a master's in 
                                Computer Science in 2023.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <div class="mb-2"><i class="bi-laptop fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">Michael Hollinger (Full Stack/Web Developer)</h3>
                            <p class="text-muted mb-0">My name is Michael Hollinger. I am a computer science major at Florida Atlantic University. I expect to graduate in Spring 2023 with my B.S. in computer science.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <div class="mb-2"><i class="bi-laptop fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">Kamal Shrouder (Back-end/Developer)</h3>
                            <p class="text-muted mb-0">Hi! My name is Kamal Shrouder and I am currently a senior, studying Computer Science at Florida Atlantic University. 
                                Expected graduation date is Summer 2022</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio-->
        <div id="portfolio">
            <div class="container-fluid p-0">
                <div class="row g-0">
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/AM.JPG" title="Avigail Martinez">
                            <img class="img-fluid" src="assets/img/portfolio/thumbnails/AM.JPG" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">LinkedIn profile:</div>
                                <div class="project-name">https://www.linkedin.com/in/avigail-martínez-0a6817191</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/JC.jpg" title="John Callaghan">
                            <img class="img-fluid" src="assets/img/portfolio/thumbnails/JC.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">LinkedIn profile:</div>
                                <div class="project-name">https://www.linkedin.com/in/john-callaghan-b10071212/</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/OH.jpg" title="Oasis Husband">
                            <img class="img-fluid" src="assets/img/portfolio/thumbnails/OH.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Linkedin profile:</div>
                                <div class="project-name">https://www.linkedin.com/in/oasis-husband/</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/KS.jpg" title="Kamal Shrouder">
                            <img class="img-fluid" src="assets/img/portfolio/thumbnails/KS.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">LinkedIn Profile:</div>
                                <div class="project-name">https://www.linkedin.com/in/kamal-shrouder-3179b016a</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/FAU.jpg" title="Florida Atlantic University">
                            <img class="img-fluid" src="assets/img/portfolio/thumbnails/FAU.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">FAU link:</div>
                                <div class="project-name">https://www.fau.edu/</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/MH.jpg" title="Michael Hollinger">
                            <img class="img-fluid" src="assets/img/portfolio/thumbnails/MH.jpg" alt="..." />
                            <div class="portfolio-box-caption p-3">
                                <div class="project-category text-white-50">Linkedin profile:</div>
                                <div class="project-name">https://www.linkedin.com/in/michael-hollinger-72bb55241/</div>
                            </div>
                        </a>
                    </div> 
                </div>
            </div>
        </div>

        <!-- Footer-->
        <footer class="bg-light py-5">
            <div class="container px-4 px-lg-5"><div class="small text-center text-muted">Copyright &copy; 2022 - Group 9 EGN4952C</div></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- SimpleLightbox plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
